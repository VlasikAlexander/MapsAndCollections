package com.example.mapsandcollections.ui;

public class MainActivityContract {

    public interface IView {

    }

    public interface IPresenter {

    }

    public interface IHost {

    }
}
