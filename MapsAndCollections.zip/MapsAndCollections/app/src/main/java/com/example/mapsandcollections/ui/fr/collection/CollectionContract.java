package com.example.mapsandcollections.ui.fr.collection;

public class CollectionContract {

    public interface IPresenter {

    }

    public interface IView {

    }

    public interface IHost {

    }
}
