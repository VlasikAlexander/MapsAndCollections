package com.example.mapsandcollections.ui.fr.map;

public class MapPresenter implements MapContract.IPresenter {

    private final MapContract.IView view;

    public MapPresenter(MapContract.IView view) {
        this.view = view;
    }


}
