package com.example.mapsandcollections.ui.fr.map;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mapsandcollections.R;
import com.example.mapsandcollections.components.Injections;

public class MapFragment extends Fragment implements MapContract.IView {

    private MapContract.IPresenter presenter;
    private MapContract.IHost host;


    public static MapFragment newInstance() {
        
        Bundle args = new Bundle();
        
        MapFragment fragment = new MapFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        presenter = Injections.getMapFragmentPresenter(this);
        return inflater.inflate(R.layout.fragment_map, null, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        host = (MapContract.IHost) context;
    }

    @Override
    public void onDetach() {
        host = null;
        super.onDetach();
    }


}
