package com.example.mapsandcollections.ui.fr.collection;

public class CollectionPresenter implements CollectionContract.IPresenter {

    final private CollectionContract.IView view;

    public CollectionPresenter(CollectionContract.IView view) {
        this.view = view;
    }
}
