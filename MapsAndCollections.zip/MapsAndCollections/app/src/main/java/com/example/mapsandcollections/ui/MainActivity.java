package com.example.mapsandcollections.ui;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.mapsandcollections.R;
import com.example.mapsandcollections.components.Injections;
import com.example.mapsandcollections.ui.fr.collection.CollectionContract;
import com.example.mapsandcollections.ui.fr.collection.CollectionFragment;
import com.example.mapsandcollections.ui.fr.map.MapFragment;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements MainActivityContract.IView {

    private MainActivityContract.IPresenter presenter;
    private List<Fragment> fragments;

    @BindView(R.id.view_pager)
    private ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initViewPager();
    }

    private void initViewPager() {
        fragments = new ArrayList<>();
        fragments.add(MapFragment.newInstance());
        fragments.add(CollectionFragment.newInstance());
        presenter = Injections.getMainActivityPresenter(this);
        viewPager.setAdapter(new MyFragmentAdapter(getSupportFragmentManager(), fragments));
    }


}
