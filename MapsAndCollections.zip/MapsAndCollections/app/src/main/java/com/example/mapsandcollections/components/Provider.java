package com.example.mapsandcollections.components;

import android.content.Context;

public class Provider implements IProvider {

    final private Context context;

    public Provider(Context context) {
        this.context = context;
    }
}
