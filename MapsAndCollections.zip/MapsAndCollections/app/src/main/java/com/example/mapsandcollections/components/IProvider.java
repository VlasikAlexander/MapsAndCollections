package com.example.mapsandcollections.components;

public interface IProvider {


}
