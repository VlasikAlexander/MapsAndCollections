package com.example.mapsandcollections.ui.fr.map;

public class MapContract {

    public interface IPresenter {

    }

    public interface IView {

    }

    public interface IHost {

    }
}
